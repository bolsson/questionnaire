This skin is for DNN 5 only - and if you try to install any site below DNN 5, you may risk the skin breaking the page.

Please use the HOSTS/SKINS / INSTALL NEW SKIN option and upload the DNN 5 zipped skin found in the folder.

You will need to repeat this process if the skin has a container set as you can no longer install skins and containers together without alot more work to be done, but we have already made changes to the files so the skins and containers appear together in the dropdown menu.

Please visit this forum - 
http://www.dnnskins.com/forums.aspx?afv=topicsview&aff=9 to post your questions and ideas.

Thank you

Nina Meiers
XD Design Inc

nina@xd.com.au

http://www.dnnskins.com
http://www.xd.com.au
http://www.dotnetnuke.net.au
http://www.modulereviews.com
http://www.skincovered.com
http://www.catalooksupport.com




